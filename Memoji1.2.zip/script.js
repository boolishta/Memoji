var picsArray = ['🐵', '🦄', '🐞', '🦀', '🐟', '🐊', '🐵', '🦄', '🐞', '🦀', '🐟', '🐊'];
shuffle(picsArray);
var allFrontArr = Array.from(document.querySelectorAll('.front'));
for(var i = 0; i<= allFrontArr.length - 1; i++) {
  allFrontArr[i].innerHTML = picsArray[i];
};
function shuffle(arr) {
  var j, x, i;
  for (i = arr.length - 1; i > 0; i--) {
      j = Math.floor(Math.random() * (i + 1));
      x = arr[i];
      arr[i] = arr[j];
      arr[j] = x;
  }
  return arr;
};

var cardClick = [];

allCards.onclick = function(e){
  var target = e.target.parentNode.id;
  if(target !== 'allCards'){
    var card = document.getElementById(target);
    var back = card.firstElementChild;
    var front = card.lastElementChild;
    back.classList.toggle('is-flipped');
    front.classList.toggle('is-flipped');
    cardClick.push(Array.from(card.childNodes));
    onlyFlip(cardClick);
    sameCard(cardClick);
  }
};

function onlyFlip(arr) {
  for(let i = arr.length - 1; i >= 0; i--) {
    if(arr[i][1].classList.contains("is-flipped")) {
      continue;
    } else {
      arr.splice(i, 1);
    }
  };
  return arr;
};

function sameCard(cardClick) {
  if(cardClick.length == 2) {
    if(cardClick[0][3].innerHTML === cardClick[1][3].innerHTML) {
      cardClick[0][3].classList.add('same');
      cardClick[1][3].classList.add('same');
      cardClick.splice(0, 2);
    } else {
        cardClick[0][3].classList.add('notsame');
        cardClick[1][3].classList.add('notsame');
        onlyFlip(cardClick);
      }
  } else if(cardClick.length === 3) {
      cardClick[0][3].classList.toggle('is-flipped');
      cardClick[0][1].classList.toggle('is-flipped');
      cardClick[1][3].classList.toggle('is-flipped');
      cardClick[1][1].classList.toggle('is-flipped');
      onlyFlip(cardClick);
      deleteNotsame();
    }
};

function deleteNotsame() {
  let notsame = Array.from(document.getElementsByClassName("notsame"));
  if(notsame[0].classList.contains("notsame")){
    notsame[0].classList.remove("notsame");
  }
  if(notsame[1].classList.contains("notsame")){
    notsame[1].classList.remove("notsame");
  }
};


